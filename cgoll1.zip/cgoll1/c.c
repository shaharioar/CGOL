#include <stdio.h>
#include <stdlib.h>

int main(){

int grid[6][6];

int p, q;
for(p=0; p<6; p++) {
for(q=0;q<6;q++) {
printf("Enter the values of grid[%d][%d]:", p, q);
fflush(stdout);
scanf("%d", &grid[p][q]);
break;
}
}
//Display elements of Array
printf("Present Generation:\n");
for(p=0; p<6; p++) {
for(q=0;q<6;q++) {

printf("%d", grid[p][q]);
}
printf("\n");
}

void fun(int n, int m, int grid[n][m]);
const int n=6,m=6;

fun(n,m,grid);

return 0;
}

void fun(int n,int m, int grid[n][m]){

int array[6][6];
int r,s;
int aliveNeighbours = 0;
for(r=0; r<6; r++){
for(s=0;s<6;s++){
aliveNeighbours = 0;
int x,y;

for (x = -1; x <= 1; x++){
for (y = -1; y <= 1; y++){

if (grid[r+x][s+y]==1){
aliveNeighbours++;

}
}
}

aliveNeighbours = aliveNeighbours - grid[r][s];

if (aliveNeighbours < 2)
array[r][s] = 0;


// Cell dies due to over population
else if (aliveNeighbours > 3)
array[r][s] = 0;


// A new cell is born
else if (aliveNeighbours == 3)
array[r][s] = 1;


// Remains the same
else if (aliveNeighbours==2){
if(grid[r][s]==1){
array[r][s]=1;
}
else
array[r][s]=0;
}
}
}

int p,q;
printf("\n");
printf("Second Generation:\n");
for(p=0; p<6; p++) {
for(q=0;q<6;q++) {

printf("%d", array[p][q]);
}
printf("\n");
}
}
